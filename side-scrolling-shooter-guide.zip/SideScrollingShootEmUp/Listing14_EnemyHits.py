#enemyNames = ['ball', 'cannon', 'cannon_top', 'flying_saucer',
#              'rocket', 'ship_alien', 'ship_cannon', 'ship_fighter', 'ship_pistol', 'big_ship' ]

enemyNumberOfHits = [1, 4, 4, 10, 1, 1, 12, 6, 12, 1000]
