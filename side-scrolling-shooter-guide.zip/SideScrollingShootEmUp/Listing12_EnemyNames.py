enemyNames = ['ball', 'cannon', 'cannon_top', 'flying_saucer',
              'rocket', 'ship_alien', 'ship_cannon', 'ship_fighter', 'ship_pistol', 'big_ship' ]
