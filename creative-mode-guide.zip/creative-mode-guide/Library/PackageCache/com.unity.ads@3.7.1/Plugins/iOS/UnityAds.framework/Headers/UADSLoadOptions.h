#import "UADSBaseOptions.h"

@interface UADSLoadOptions : UADSBaseOptions

@property (nonatomic, readwrite) NSString* adMarkup;

@end
