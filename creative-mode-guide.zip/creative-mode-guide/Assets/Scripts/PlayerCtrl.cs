﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCtrl : MonoBehaviour {
  public float flySpeed = 10f;
  public float rotateSpeed = 2f;
  Camera cam;
  Vector3 camRot = new Vector3(0, 0, 0);

  void Start() {
    Cursor.lockState = CursorLockMode.Locked;
    Cursor.visible = false;
    cam = Camera.main;
  }

  void Update() {
    float mouseX = Input.GetAxis("Mouse X");
    float mouseY = Input.GetAxis("Mouse Y");

    transform.RotateAround(transform.position, Vector3.up, mouseX * rotateSpeed);
    
    camRot.x += -mouseY * rotateSpeed;
    camRot.x = Mathf.Clamp(camRot.x, -90, 90);
    cam.transform.localEulerAngles = camRot;

    float vertInput = Input.GetAxis("Vertical");
    float horiInput = Input.GetAxis("Horizontal");
    float jumpInput = Input.GetAxis("Jump") - Input.GetAxis("Fire3");
    
    Vector3 move = Vector3.zero;
    move.x += horiInput * flySpeed;
    move.y += jumpInput * flySpeed;
    move.z += vertInput * flySpeed;
    transform.Translate(move * Time.deltaTime);
  }
}