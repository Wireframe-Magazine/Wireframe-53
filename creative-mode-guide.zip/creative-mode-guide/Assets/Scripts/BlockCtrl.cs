﻿using System;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BlockCtrl : MonoBehaviour {
  public float buildReach = 10f;
  public GameObject[] blockCatalog;
  int activeID = 0;
  GameObject blockGroup;
  Camera cam;
  GameObject blockPreview;
  
  void Start() {
    cam = Camera.main;
    blockGroup = new GameObject("---Block Group---");
    GenBlock(Vector3.zero);
    RenderPreview();
  }

  void Update() {
    float scrollInput = Input.GetAxis("Mouse ScrollWheel");
    if(scrollInput > 0) {
      activeID++;
      if(activeID > blockCatalog.Length-1) {
        activeID = 0;
      }
      RenderPreview();
    }
    else if(scrollInput < 0){
      activeID--;
      if(activeID < 0){
        activeID = blockCatalog.Length-1;
      }
      RenderPreview();
    }

    RaycastHit pointRay1;
    if (Physics.Raycast(cam.ScreenPointToRay(Input.mousePosition), out pointRay1, buildReach)){
      Mesh hitMesh = pointRay1.collider.gameObject.GetComponent<MeshFilter>().mesh;
      Vector3[] verts = hitMesh.vertices;
      int[] tris = hitMesh.triangles;

      int triangleStartIndex = pointRay1.triangleIndex*3;
      
      int vertIndex0 = tris[triangleStartIndex];
      int vertIndex1 = tris[triangleStartIndex + 1];
      int vertIndex2 = tris[triangleStartIndex + 2];

      Vector3 point0 = verts[vertIndex0];
      Vector3 point1 = verts[vertIndex1];
      Vector3 point2 = verts[vertIndex2];
      
      Vector3 side1 = point1 - point0;
      Vector3 side2 = point2 - point0;
      Vector3 triNormal = Vector3.Cross(side1, side2);
      triNormal = triNormal.normalized;

      Vector3 newBlockPos = pointRay1.transform.position + triNormal;

      if ( Input.GetButtonDown("Fire2") ) {
        GenBlock(newBlockPos);
        blockPreview.GetComponent<Animator>().SetTrigger("buildTrigger");
      }

      if( Input.GetButtonDown("Fire1") ){
        Destroy(pointRay1.collider.gameObject);
        blockPreview.GetComponent<Animator>().SetTrigger("buildTrigger");
      }
    }
  }

  void RenderPreview() {
    Destroy(blockPreview);
    blockPreview = Instantiate(blockCatalog[activeID], cam.transform);
    blockPreview.transform.localPosition = new Vector3(1,-1,2);
  }

  GameObject GenBlock(Vector3 pos){
    GameObject blockObj = Instantiate(blockCatalog[activeID], pos, Quaternion.identity, blockGroup.transform);
    blockObj.name = "Block";
    return blockObj;
  }
}